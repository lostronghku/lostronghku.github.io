var map; 
var geocoder = new google.maps.Geocoder(); /** *-25.363882,131.044922 *初始地图 */

function initialize(lat1, lng1, zoom, canvas_div) {
    var myLatlng = new google.maps.LatLng(lat1, lng1);
    var myOptions = {
        zoom: zoom,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    map = new google.maps.Map(document.getElementById(canvas_div), myOptions);
}
//根据坐标点 mark 标记 在初始地图时
function placeMarker(latLng,html) {
    var marker = new google.maps.Marker({
        position: latLng,
        map: map,
        cursor: "1",
        flat: true,
        draggable: false,
        clickable: true,
        visible: true
    });
    map.setCenter(latLng);
    var infowindow = new google.maps.InfoWindow({ content: html });
   // infowindow.setPosition(latLng);    infowindow.open(map, marker);
}

function initMap(myLatLng,drawLatLng) {
  //  65267(49.0059,8.40308)  44799(48.9881,8.37332)  44802(49.0004,8.39582)  44804(49.0098,8.40257)  

  
 // myLatLng.push({lat: 33.6889, lng: -112.098});


  var map = new google.maps.Map(document.getElementById('map_canvas'), {
    zoom: 16,
    center: myLatLng[0]
  });

var contentString1 = 'Starbucks';
var contentString2 = 'Library';
var contentString3 = 'Apartment';
// var contentString4 = '4';

  var infowindow1 = new google.maps.InfoWindow({
    content: contentString1,
    maxWidth: 200
  });

  var infowindow2 = new google.maps.InfoWindow({
    content: contentString2,
    maxWidth: 200
  });

  var infowindow3 = new google.maps.InfoWindow({
    content: contentString3,
    maxWidth: 200
  });

  // var infowindow4 = new google.maps.InfoWindow({
  //   content: contentString4,
  //   maxWidth: 200
  // });
var image1 = 'flg1.png';
var image2 = 'flg2.png';
var image3 = 'flg3.png';

  var marker0 = new google.maps.Marker({
    position: myLatLng[0],
    map: map,
    title: 'Hello World!'
  });

 // marker0.addListener('click', function() {
    infowindow1.open(map, marker0);
 // });
  var marker1 = new google.maps.Marker({
    position: myLatLng[1],
    map: map,
    title: 'Hello World!',
 //   icon:image1
  });
 // marker1.addListener('click', function() {
    infowindow2.open(map, marker1);
 // });
  var marker2 = new google.maps.Marker({
    position: myLatLng[2],
    map: map,
    title: 'Hello World!',
 //   icon:image2
  });
 // marker2.addListener('click', function() {
    infowindow3.open(map, marker2);
 // });
 //  var marker3 = new google.maps.Marker({
 //    position: myLatLng[3],
 //    map: map,
 //    title: 'Hello World!',
 //  //  icon:image3
 //  });
 // // marker3.addListener('click', function() {
 //    infowindow4.open(map, marker3);
 // });
 // var marker4 = new google.maps.Marker({
 //   position: myLatLng[4],
 //   map: map,
 //   title: 'Hello World!'
 // });

  var flightPath = new google.maps.Polyline({
    path: drawLatLng,
    geodesic: true,
    strokeColor: '#FF0000',
    strokeOpacity: 1.0,
    strokeWeight: 2
  });

  flightPath.setMap(map);
}

//根据地址获取坐标
function codeAddress(latitude, longitude,html, address, Fun) {
    if (0 == latitude || 0 == longitude) {
        if (geocoder) {
            geocoder.geocode(
                { 'address': address }, 
                function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    Fun(results[0].geometry.location, html);
                } 
                else {
                    Fun(latLng,html);
                    //.return false;                    //alert("Geocode was not successful for the following reason: " + status);                }
                }
            }
            );
        
    } else {
        placeMarker(new google.maps.LatLng(latitude, longitude),html);
    }
    }
}
$(function () {

//   alpha 0.1
//   The result based on similarity measure: (Top-1)
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.131711 lat: 55.9496, lng: -3.19194  
// Pair-wise distances: 112.558 108.625 210.56 
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.156647 lat: 55.9503, lng: -3.18874  stars: 0.9review_cnt: 0.131711 lat: 55.9496, lng: -3.19194  
// Pair-wise distances: 124.747 108.625 214.065 
// Sim=1 stars: 0.9review_cnt: 0.174882 lat: 55.9587, lng: -3.20976  stars: 0.9review_cnt: 0.132350 lat: 55.9591, lng: -3.21113  stars: 0.9review_cnt: 0.132171 lat: 55.9589, lng: -3.20773  
// Pair-wise distances: 100.891 128.547 214.253 
// Sim=1 stars: 0.9review_cnt: 0.169680 lat: 55.9485, lng: -3.19307  stars: 0.9review_cnt: 0.144274 lat: 55.948, lng: -3.19179 stars: 0.9review_cnt: 0.145002 lat: 55.9496, lng: -3.19245  
// Pair-wise distances: 100.579 123.076 182.474 
// Sim=1 stars: 0.9review_cnt: 0.169680 lat: 55.9485, lng: -3.19307  stars: 0.9review_cnt: 0.131672 lat: 55.948, lng: -3.19198 stars: 0.9review_cnt: 0.145002 lat: 55.9496, lng: -3.19245  
// Pair-wise distances: 89.5035 123.076 177.466 

// alpha 0.5

// The result based on similarity measure: (Top-1)
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.131711 lat: 55.9496, lng: -3.19194  
// Pair-wise distances: 112.558 108.625 210.56 
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.156647 lat: 55.9503, lng: -3.18874  stars: 0.9review_cnt: 0.131711 lat: 55.9496, lng: -3.19194  
// Pair-wise distances: 124.747 108.625 214.065 
// Sim=1 stars: 0.9review_cnt: 0.174882 lat: 55.9587, lng: -3.20976  stars: 0.9review_cnt: 0.132350 lat: 55.9591, lng: -3.21113  stars: 0.9review_cnt: 0.132171 lat: 55.9589, lng: -3.20773  
// Pair-wise distances: 100.891 128.547 214.253 
// Sim=1 stars: 0.9review_cnt: 0.169680 lat: 55.9485, lng: -3.19307  stars: 0.9review_cnt: 0.144274 lat: 55.948, lng: -3.19179 stars: 0.9review_cnt: 0.145002 lat: 55.9496, lng: -3.19245  
// Pair-wise distances: 100.579 123.076 182.474 
// Sim=1 stars: 0.9review_cnt: 0.169680 lat: 55.9485, lng: -3.19307  stars: 0.9review_cnt: 0.131672 lat: 55.948, lng: -3.19198 stars: 0.9review_cnt: 0.145002 lat: 55.9496, lng: -3.19245  
// Pair-wise distances: 89.5035 123.076 177.466 

// alpha 0
// The result based on similarity measure: (Top-1)
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.143816 lat: 55.95, lng: -3.19123  
// Pair-wise distances: 112.558 85.5364 159.922 
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.131711 lat: 55.9496, lng: -3.19194  
// Pair-wise distances: 112.558 108.625 210.56 
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.132171 lat: 55.9589, lng: -3.20773  
// Pair-wise distances: 112.558 1509.61 1541.88 
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.132802 lat: 55.9534, lng: -3.11618  
// Pair-wise distances: 112.558 4633.6 4533 
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.133085 lat: 55.9405, lng: -3.27798  
// Pair-wise distances: 112.558 5563.64 5668.64 

// alpha 1

// The result based on similarity measure: (Top-1)
// Sim=1 stars: 0.9review_cnt: 0.163956 lat: 55.9495, lng: -3.1902 stars: 0.9review_cnt: 0.169550 lat: 55.95, lng: -3.18866  stars: 0.9review_cnt: 0.131711 lat: 55.9496, lng: -3.19194  
// Pair-wise distances: 112.558 108.625 210.56 
// Sim=1 stars: 0.6review_cnt: 0.232013 lat: 55.946, lng: -3.2053  stars: 0.7review_cnt: 0.157077 lat: 55.9458, lng: -3.20351  stars: 0.6review_cnt: 0.144022 lat: 55.9467, lng: -3.20648  
// Pair-wise distances: 114.433 108.123 213.024 
// Sim=1 stars: 0.8review_cnt: 0.231911 lat: 55.95, lng: -3.1888 stars: 0.8review_cnt: 0.145788 lat: 55.9508, lng: -3.18764  stars: 0.8review_cnt: 0.432367 lat: 55.9498, lng: -3.19058  
// Pair-wise distances: 113.577 112.729 211.484 
// Sim=1 stars: 0.8review_cnt: 0.132971 lat: 55.9507, lng: -3.18914  stars: 0.8review_cnt: 0.131556 lat: 55.9507, lng: -3.19096  stars: 0.9review_cnt: 0.336526 lat: 55.9502, lng: -3.18762  
// Pair-wise distances: 113.804 110.214 214.717 
// Sim=1 stars: 0.8review_cnt: 0.235219 lat: 55.9487, lng: -3.19326  stars: 0.9review_cnt: 0.331980 lat: 55.948, lng: -3.19434 stars: 0.9review_cnt: 0.145002 lat: 55.9496, lng: -3.19245  
// Pair-wise distances: 109.219 104.408 212.877 


    //    initialize('0.000000', '0.000000', 16, 'map_canvas');
     //     var html = 'googlemap';
      //  codeAddress('0.000000', '0.000000',html, addr, placeMarker);  
  //     var myLatLng=[];
  //     myLatLng.push({lat: 49.0059, lng: 8.40308});
  //     myLatLng.push({lat: 48.9881, lng: 8.37332});
  //     myLatLng.push({lat: 49.0004, lng: 8.39582});
  //     myLatLng.push({lat: 49.0098, lng: 8.40257});

  //     var drawLatLng =[];
  //  drawLatLng.push({lat: 48.9881, lng: 8.37332});
  // drawLatLng.push({lat: 49.0004, lng: 8.39582});
  //  drawLatLng.push({lat: 49.0059, lng: 8.40308});
  // drawLatLng.push({lat: 49.0098, lng: 8.40257});
  // drawLatLng.push({lat: 48.9881, lng: 8.37332});
  // initMap(myLatLng,drawLatLng); 

  var myLatLng =[];
  //  myLatLng.push({lat: 49.0086, lng: 8.40059});
  //   myLatLng.push({lat: 48.9881, lng: 8.37332});
  //  myLatLng.push({lat: 49.0004, lng: 8.39582});
  // myLatLng.push({lat: 49.0098, lng: 8.40257});
  // myLatLng.push({lat: 49.0086, lng: 8.40059});

// myLatLng.push({lat:  33.4817, lng: -111.924});
//     myLatLng.push({lat: 33.4962, lng: -111.964});
//    myLatLng.push({lat: 33.4754, lng: -112.22});
//   myLatLng.push({lat:  33.4817, lng: -111.924});

// query 1: 63956(55.9495,-3.1902)  69550(55.95,-3.18866) 31711(55.9496,-3.19194) 
// stars: 0.9review_cnt: 0.163956   stars: 0.9review_cnt: 0.169550    stars: 0.9review_cnt: 0.131711
// myLatLng.push({lat:  55.9495, lng: -3.1902});
//     myLatLng.push({lat: 55.95, lng: -3.18866});
//    myLatLng.push({lat: 55.9496, lng: -3.19194});
//   myLatLng.push({lat:  55.9495, lng: -3.1902});

// alpha=0.5 result1: 63956(55.9495,-3.1902)  56647(55.9503,-3.18874) 31711(55.9496,-3.19194) 
// stars: 0.9review_cnt: 0.163956   stars: 0.9review_cnt: 0.156647    stars: 0.9review_cnt: 0.131711
// myLatLng.push({lat:  55.9495, lng: -3.1902});
//     myLatLng.push({lat: 55.9503, lng: -3.18874});
//    myLatLng.push({lat: 55.9496, lng: -3.19194});
//   myLatLng.push({lat:  55.9495, lng: -3.1902});

// alpha=0.5 result2: 74882(55.9587,-3.20976) 32350(55.9591,-3.21113) 32171(55.9589,-3.20773) 
// stars: 0.9review_cnt: 0.174882      stars: 0.9review_cnt: 0.132350        stars: 0.9review_cnt: 0.132171
// myLatLng.push({lat:  55.9587, lng: -3.20976});
//     myLatLng.push({lat: 55.9591, lng: -3.21113});
//    myLatLng.push({lat: 55.9589, lng: -3.20773});
//   myLatLng.push({lat:  55.9587, lng: -3.20976});


// myLatLng.push({lat: 55.9495, lng: -3.1902});
//     myLatLng.push({lat: 55.9503, lng: -3.18874});
//    myLatLng.push({lat: 55.9496, lng: -3.19194});
//   myLatLng.push({lat: 55.9495, lng: -3.1902});


// range keyword query
myLatLng.push({lat: 55.9495,lng:-3.1902});
myLatLng.push({lat: 55.9406,lng:-3.20396});
myLatLng.push({lat: 55.9496,lng:-3.19194});
myLatLng.push({lat: 55.9495,lng:-3.1902});

// example
// myLatLng.push({lat: 55.9495,lng:-3.1902});
// myLatLng.push({lat: 55.95,lng:-3.18866});
// myLatLng.push({lat: 55.9496,lng:-3.19194});
// myLatLng.push({lat: 55.9495,lng:-3.1902});
  
  var drawLatLng=myLatLng;
   initMap(myLatLng,drawLatLng);    
  
    });