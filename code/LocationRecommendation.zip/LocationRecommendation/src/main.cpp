/* 
 * File:   main.cpp
 * Author: hjf
 *
 * Created on April 15, 2016, 9:10 PM
 */

#include <cstdlib>
#include <cstdio>
#include<fstream>
#include<vector>
#include<set>
#include<sstream>
#include<cmath>
#include <queue>
#include<assert.h>
#include<time.h>
#include <sys/time.h>
#include<map>

#include "Node.h"
#include "utility.h"

using namespace std;
int sumHash[1000000];
vector<vector<int> > detailHash;
vector<vector<int> > changedDetailHash;
vector<Node> NodeSet;
vector<double> RadioSet;
int numMapping[10];
int COUNT = 0;

double percentage = 0;
vector<vector<double> > SpatialVector;

map<string, set<int> > InvertedList;

double alpha = 0.5;
double magnitude;
int K = 5;

double CostInSpatialUb = 0;

//double SpatialUB = 0;
long double sim(Node a, Node b);
long double avgTextualSim(Node a, int index, vector<vector<int> >&QuerySet);
bool checkDist(double R, int a, int b);
vector<PNode> FilterTypeByText(vector<Node> &nodeset, string type, double,
		double);
vector<string> split(string s, char c) {
	vector<string> ans;
	string temp = "";
	for (int i = 0; i < s.size(); i++) {
		if (s[i] == c) {
			if (temp.size() > 0 && temp[0] != ',')
				ans.push_back(temp);
			temp = "";
		} else if (s[i] != ':' && s[i] != ' ' && s[i] != ',') {
			temp += s[i];
		}
	}
	if (temp.size() > 0)
		ans.push_back(temp);
	return ans;
}

void stringToint(int &a, string s) {
	std::stringstream ss;
	ss << s;
	ss >> a;
}

void stringToDouble(double &a, string s) {
	std::stringstream ss;
	ss << s;
	ss >> a;
}

void Read(vector<Node> &nodeset, string path) {
	ifstream ifile;
	ifile.open(path.c_str());
	cout << path.c_str() << endl;
	if (ifile.fail()) {
		cout << "file cannot found" << endl;
	}
	string str;

	double maxstar = 0;
	double maxReviewCount = 0;
	int tempCnt = 0;
	int line = 0;
	while (getline(ifile, str)) {
		line++;
		Node node;
		vector<string> ans = split(str, ';');
		if (line == 150)
			cout << ans[0] << " " << ans[1] << " " << ans[2] << " " << ans[3]
					<< " " << ans[4] << " " << ans[5] << " " << ans[6] << " "
					<< ans[7] << " " << ans[8] << " " << ans[9] << " "
					<< ans[10] << endl;

		stringToint(node.business_id, ans[0]);
		node.name = ans[1];
		stringToDouble(node.latitude, ans[2]);
		stringToDouble(node.longitude, ans[3]);
		stringToDouble(node.stars, ans[4]);
		stringToDouble(node.review_count, ans[5]);

		maxstar = max(maxstar, node.stars);
		maxReviewCount = max(maxReviewCount, node.review_count);
		int num;
		stringToint(num, ans[6]);
//        num = min(1, num);
		for (int i = 0; i < num; i++) {
			if (line == 150)
				cout << "i:" << ans[7 + i] << " ";
			node.categories.insert(ans[7 + i]);
		}
		nodeset.push_back(node);
	}
	cout << "tempCnt:" << tempCnt << endl;
	cout << nodeset.size() << endl;
	for (int i = 0; i < nodeset.size(); i++) {
		nodeset[i].stars /= maxstar;
		if (nodeset[i].review_count <= 10)
			nodeset[i].review_count = 0.1;
		else if (nodeset[i].review_count <= 50)
			nodeset[i].review_count = 0.2;
		else if (nodeset[i].review_count <= 100)
			nodeset[i].review_count = 0.3;
		else if (nodeset[i].review_count <= 150)
			nodeset[i].review_count = 0.4;
		else if (nodeset[i].review_count <= 200)
			nodeset[i].review_count = 0.5;
		else if (nodeset[i].review_count <= 500)
			nodeset[i].review_count = 0.6;
		else if (nodeset[i].review_count <= 1000)
			nodeset[i].review_count = 0.7;
		else if (nodeset[i].review_count <= 2000)
			nodeset[i].review_count = 0.8;
		else if (nodeset[i].review_count <= 3000)
			nodeset[i].review_count = 0.9;
		else
			nodeset[i].review_count = 1;

		//nodeset[i].review_count/=maxReviewCount;
	}
	ifile.close();
	//  cout<<maxstar <<"  "<<maxReviewCount<<endl;
	//    for(int i=0;i<100;i++)
	//    {
	//        cout<<nodeset[i].stars<<"  "<<nodeset[i].review_count<<endl;
	//    }

}
double dist(double lat1, double lon1, double lat2, double lon2) {
	return Spherical_distance(lat1, lon1, lat2, lon2);
	//   return sqrt((lat1 - lat2)*(lat1 - lat2) + (lon1 - lon2)*(lon1 - lon2));
}

double dist(vector<Node>& nodeset, int id1, int id2) {
//	return dist(nodeset[id1].latitude, nodeset[id1].longitude, nodeset[id2].latitude, nodeset[id2].longitude);
	return Spherical_distance(nodeset[id1].latitude, nodeset[id1].longitude,
			nodeset[id2].latitude, nodeset[id2].longitude);
}

vector<PNode> FilterType(vector<Node> &nodeset, int id, int index,
		vector<vector<int> > &querySet, double r) {
	vector<PNode> ans;

	int count = 0;
	//for (int i = 0; i < nodeset.size(); i++) {
	//   if (i == id) continue;
	bool used[nodeset.size() + 1];
	memset(used, 0, sizeof(used));
	for (auto e : nodeset[id].categories) {
		for (auto item : InvertedList[e]) {
			if (used[item] || checkDist(r, id, item) == false)
				continue;
			ans.push_back(
					PNode(item, avgTextualSim(nodeset[item], index, querySet),
							dist(NodeSet[id].latitude, NodeSet[id].longitude,
									NodeSet[item].latitude,
									NodeSet[item].longitude)));
			used[item] = 1;
			//count++;
			//if (count > 100) return ans;
		}
	}
	return ans;
}

/*
 * This method searches a list of nodes (PNodes) that are of the type indicated by "type" parameter, while the review_count is at most
 * the parameter "review_count" and the stars is at most the parameter "stars"
 * @author Siqiang
 * @param type 		the type of the returned list of nodes
 * @param review_count 		the first feature of "texture similarity"; if review_count=0, then it means we do not care the threshold
 * @param stars		the second feature of "texture similarity"; if stars=0, then it means we do not care the threshold
 *
 */
vector<PNode> FilterTypeByText(vector<Node> &nodeset, string type,
		double review_count, double stars) {
	double nearZero = 0.000001;
	vector<PNode> ans;
	cout << type << " " << InvertedList[type].size() << endl;
	for (int item : InvertedList[type]) {
		if (review_count > nearZero) {
			if (nodeset[item].review_count < review_count)
				continue;
		}

		if (stars > nearZero) {
			if (nodeset[item].stars < stars)
				continue;
		}
		ans.push_back(PNode(item, 0, 0));
	}

	return ans;
}

void findSmallestSumDistance(vector<Node>& nodeset, string type1, string type2,
		string type3, string locationtype) {
	vector<PNode> list1 = FilterTypeByText(nodeset, type1, 0, 0);
	vector<PNode> list2 = FilterTypeByText(nodeset, type2, 0, 0);
	vector<PNode> list3 = FilterTypeByText(nodeset, type3, 0, 0);
	vector<PNode> list4 = FilterTypeByText(nodeset, locationtype, 0, 0);
	cout << list1.size() << " " << list2.size() << " " << list3.size() << " "
			<< list4.size() << endl;
	double minDist = 1000000000;
	int id1, id2, id3, locationId;
	for (int i = 0; i < list1.size(); i++) {
		for (int j = 0; j < list2.size(); j++) {
			for (int u = 0; u < list3.size(); u++) {
				for (int v = 0; v < list4.size(); v++) {
					double d1 = dist(nodeset, list1[i].id, list4[v].id);
					double d2 = dist(nodeset, list2[j].id, list4[v].id);
					double d3 = dist(nodeset, list3[u].id, list4[v].id);

					if (d1 + d2 + d3 < minDist) {
						minDist = d1 + d2 + d3;
						id1 = i;
						id2 = j;
						id3 = u;
						locationId = v;
					}
				}
			}
		}
	}
	cout << locationId << " " << id1 << " " << id2 << " " << id3 << ": "
			<< dist(nodeset, id1, locationId) << " "
			<< dist(nodeset, id2, locationId) << " "
			<< dist(nodeset, id3, locationId) << endl;
}

/*
 * This method is for case study. The case contains 3 nodes, the types of which are respectively indicated by
 * type1, type2 and locationtype
 * @author Siqiang
 * @param nodeset
 * @param type1 	the type of the first facilitate node, e.g., library
 * @param type2 	the type of the second facilitate node, e.g., bookstore
 * @param locationtype 		the type of the returned location node, e.g., hotel
 */
vector<vector<int> > CaseStudyFor3Nodes(vector<Node>& nodeset, string type1, string type2,
		string locationtype, int k) {
	vector<vector<int> > examples;
	cout << "----------------------------------" << endl;
	cout << "Basic statistics:" << endl;
	//find the nodes that are of the type "type1" and the review_count and stars are respectively at most
	double reviewCntThresh = 0.1;
	double starThresh = 0.9;
	vector<PNode> list1 = FilterTypeByText(nodeset, type1, reviewCntThresh,
			starThresh);
	vector<PNode> list2 = FilterTypeByText(nodeset, type2, reviewCntThresh,
			starThresh);
	vector<PNode> list3 = FilterTypeByText(nodeset, locationtype,
			reviewCntThresh, starThresh);
	cout << "The sizes of the nodes of type " << type1
			<< " and with review_count at most " << reviewCntThresh
			<< " and stars at most " << starThresh << " is " << list1.size()
			<< endl;
	cout << "The sizes of the nodes of type " << type2
			<< " and with review_count at most " << reviewCntThresh
			<< " and stars at most " << starThresh << " is " << list2.size()
			<< endl;
	cout << "The sizes of the nodes of type " << locationtype
			<< " and with review_count at most " << reviewCntThresh
			<< " and stars at most " << starThresh << " is " << list3.size()
			<< endl;
	cout << "----------------------------------" << endl;
	cout << endl << endl;
	priority_queue<QueueNode> que;

	cout << "----------------------------------" << endl;
	cout << "Case 1:  Start searching the top-" << k
			<< " 3-node combinations, with respect to the smallest value of d1+d2 (aggregate distances)"
			<< endl;
	for (int i = 0; i < list1.size(); i++) {
		for (int j = 0; j < list2.size(); j++) {
			for (int u = 0; u < list3.size(); u++) {
				// d1 is the distance between the first node and the returned node
				double d1 = Spherical_distance(nodeset[list1[i].id].latitude,
						nodeset[list1[i].id].longitude,
						nodeset[list3[u].id].latitude,
						nodeset[list3[u].id].longitude);
				// d2 is the distance between the second node and the returned node
				double d2 = Spherical_distance(nodeset[list2[j].id].latitude,
						nodeset[list2[j].id].longitude,
						nodeset[list3[u].id].latitude,
						nodeset[list3[u].id].longitude);

				vector<int> combination;
				combination.push_back(list1[i].id);
				combination.push_back(list2[j].id);
				combination.push_back(list3[u].id);
				if (que.size() < k) {
					que.push(QueueNode(combination, -(d1 + d2), 1));
				} else if (-(d1 + d2) > que.top().weight) {
					que.pop();
					que.push(QueueNode(combination, -(d1 + d2), 1));
				}
			}
		}
	}
	cout << endl;
	// output the results
	cout << "The top-" << k
			<< " combinations are for aggregate distance searches:" << endl;
	for (int i = 0; i < k; i++) {
		QueueNode qNode = que.top();
		int id1 = qNode.id[0];
		int id2 = qNode.id[1];
		int locationId = qNode.id[2];
		double d1 = Spherical_distance(nodeset[id1].latitude,
				nodeset[id1].longitude, nodeset[locationId].latitude,
				nodeset[locationId].longitude);
		double d2 = Spherical_distance(nodeset[id2].latitude,
				nodeset[id2].longitude, nodeset[locationId].latitude,
				nodeset[locationId].longitude);

		cout << locationId << "(" << nodeset[locationId].latitude << ","
				<< nodeset[locationId].longitude << ")" << " " << id1 << "("
				<< nodeset[id1].latitude << "," << nodeset[id1].longitude << ")"
				<< " " << id2 << "(" << nodeset[id2].latitude << ","
				<< nodeset[id2].longitude << ")" << ": " << d1 << " " << d2
				<< " " << d1 + d2 << endl;
		que.pop();
	}

	cout << "----------------------------------" << endl;
	cout << endl << endl;

	cout << "----------------------------------" << endl;
	cout
			<< "Case2:  Start searching the nodes each of which are within a specific distance to first and second nodes..."
			<< endl;
	cout << "The results are list as follows (if any):" << endl;
	double radius = 1500.0;
	int cnt=0;
	int ex_num=20;
	for (int i = 0; i < list1.size() && cnt<ex_num; i++) {
		for (int j = 0; j < list2.size() && cnt<ex_num; j++) {
			for (int u = 0; u < list3.size() && cnt<ex_num; u++) {
				double d1 = Spherical_distance(nodeset[list1[i].id].latitude,
						nodeset[list1[i].id].longitude,
						nodeset[list3[u].id].latitude,
						nodeset[list3[u].id].longitude);
				double d2 = Spherical_distance(nodeset[list2[j].id].latitude,
						nodeset[list2[j].id].longitude,
						nodeset[list3[u].id].latitude,
						nodeset[list3[u].id].longitude);
				double d3 = Spherical_distance(nodeset[list1[i].id].latitude,
										nodeset[list1[i].id].longitude,
										nodeset[list2[j].id].latitude,
										nodeset[list2[j].id].longitude);
//				if (d1 < radius && d2 < radius) {
				if((d1+d2+d3)/3.0<1200 && (d1+d2+d3)/3.0>800){
					int id1 = list1[i].id;
					int id2 = list2[j].id;
					int locationId = list3[u].id;
					cout << locationId << "(" << nodeset[locationId].latitude
							<< "," << nodeset[locationId].longitude << ")"
							<< " " << id1 << "(" << nodeset[id1].latitude << ","
							<< nodeset[id1].longitude << ")" << " " << id2
							<< "(" << nodeset[id2].latitude << ","
							<< nodeset[id2].longitude << ")" << ": " << d1
							<< " " << d2 << " " << d3 << endl;
					cout<<endl;
					cout<<"The input example "<<cnt<< " is:"<<endl;
					cout<<"myLatLng.push({lat: "<<nodeset[locationId].latitude<<","<<
							"lng:"<<nodeset[locationId].longitude<<"});"<<endl;
					cout<<"myLatLng.push({lat: "<<nodeset[id1].latitude<<","<<
												"lng:"<<nodeset[id1].longitude<<"});"<<endl;
					cout<<"myLatLng.push({lat: "<<nodeset[id2].latitude<<","<<
												"lng:"<<nodeset[id2].longitude<<"});"<<endl;
					cout<<"myLatLng.push({lat: "<<nodeset[locationId].latitude<<","<<
												"lng:"<<nodeset[locationId].longitude<<"});"<<endl;
					vector<int> exp;
					exp.push_back(id1);exp.push_back(id2);exp.push_back(locationId);
					examples.push_back(exp);
					cout<<endl;
					cnt++;
					break;
				}
			}
		}
	}

	cnt=0;
		for (int i = 0; i < list1.size() && cnt<ex_num; i++) {
			for (int j = 0; j < list2.size() && cnt<ex_num; j++) {
				for (int u = 0; u < list3.size() && cnt<ex_num; u++) {
					double d1 = Spherical_distance(nodeset[list1[i].id].latitude,
							nodeset[list1[i].id].longitude,
							nodeset[list3[u].id].latitude,
							nodeset[list3[u].id].longitude);
					double d2 = Spherical_distance(nodeset[list2[j].id].latitude,
							nodeset[list2[j].id].longitude,
							nodeset[list3[u].id].latitude,
							nodeset[list3[u].id].longitude);
					double d3 = Spherical_distance(nodeset[list1[i].id].latitude,
											nodeset[list1[i].id].longitude,
											nodeset[list2[j].id].latitude,
											nodeset[list2[j].id].longitude);
					if (d1 < radius && d2 < radius) {
//					if((d1+d2+d3)/3.0<500){
						int id1 = list1[i].id;
						int id2 = list2[j].id;
						int locationId = list3[u].id;
						cout << locationId << "(" << nodeset[locationId].latitude
								<< "," << nodeset[locationId].longitude << ")"
								<< " " << id1 << "(" << nodeset[id1].latitude << ","
								<< nodeset[id1].longitude << ")" << " " << id2
								<< "(" << nodeset[id2].latitude << ","
								<< nodeset[id2].longitude << ")" << ": " << d1
								<< " " << d2 << " " << d3 << endl;
						cout<<endl;
						cout<<"The ranged keyword query result is:"<<endl;
						cout<<"myLatLng.push({lat: "<<nodeset[locationId].latitude<<","<<
								"lng:"<<nodeset[locationId].longitude<<"});"<<endl;
						cout<<"myLatLng.push({lat: "<<nodeset[id1].latitude<<","<<
													"lng:"<<nodeset[id1].longitude<<"});"<<endl;
						cout<<"myLatLng.push({lat: "<<nodeset[id2].latitude<<","<<
													"lng:"<<nodeset[id2].longitude<<"});"<<endl;
						cout<<"myLatLng.push({lat: "<<nodeset[locationId].latitude<<","<<
													"lng:"<<nodeset[locationId].longitude<<"});"<<endl;
						cout<<endl;
						cnt++;
						break;
					}
				}
			}
		}
	cout << "Search ends..." << endl;
	cout << "----------------------------------" << endl;
	cout << endl << endl;
	return examples;
}

double getAggregateDist(vector<Node> &NodeSet, int id, vector<int> &remainSet) {
	double ans = 0;
	for (int i = 0; i < remainSet.size(); i++) {
		ans += dist(NodeSet[id].latitude, NodeSet[id].longitude,
				NodeSet[remainSet[i]].latitude,
				NodeSet[remainSet[i]].longitude);
	}
	return ans;
}

bool check(vector<Node> &NodeSet, int id1, double dist1, int id2, double dist2) //j dominates i
		{

	if (dist2 > dist1)
		return false;

	if (NodeSet[id2].stars < NodeSet[id1].stars)
		return false;

	if (NodeSet[id2].review_count < NodeSet[id1].review_count)
		return false;

	return true;
}

//vector<int> getSkyline(vector<Node> &NodeSet, int id, vector<int> &remainSet) {
//    vector<int> candidate = FilterType(NodeSet, id);
//    vector<double> candidate_dist;
//    for (int i = 0; i < candidate.size(); i++) {
//        candidate_dist.push_back(getAggregateDist(NodeSet, candidate[i], remainSet));
//    }
//
//    int n = candidate.size();
//    bool dominated[n + 1];
//    memset(dominated, 0, sizeof (dominated));
//    for (int i = 0; i < n; i++) {
//        for (int j = 0; j < n; j++) {
//            if (i == j || dominated[j]) continue;
//            if (check(NodeSet, candidate[i], candidate_dist[i], candidate[j], candidate_dist[j])) //j dominates i, true;  otherwise false
//            {
//                dominated[i] = true;
//                break;
//            }
//        }
//    }
//    vector<int> ans;
//    for (int i = 0; i < n; i++) {
//        if (!dominated[i]) {
//            ans.push_back(candidate[i]);
//            cout << NodeSet[candidate[i]].stars << "  " << NodeSet[candidate[i]].review_count << "  " << candidate_dist[i] << endl;
//        }
//    }
//    return ans;
//}

//bool checkSkyline(vector<Node> &NodeSet, int id, vector<int> &remainSet) {
//    vector<int> candidate = FilterType(NodeSet, id);
//    vector<double> candidate_dist;
//    for (int i = 0; i < candidate.size(); i++) {
//        candidate_dist.push_back(getAggregateDist(NodeSet, candidate[i], remainSet));
//    }
//
//    double dist = getAggregateDist(NodeSet, id, remainSet);
//    int n = candidate.size();
//    bool dominated[n + 1];
//    memset(dominated, 0, sizeof (dominated));
//    for (int i = 0; i < n; i++) {
//        if (check(NodeSet, id, dist, candidate[i], candidate_dist[i])) //i dominates id, true;  otherwise false
//        {
//            return false;
//        }
//    }
//    return true;
//}

//vector<int> TransNodeSetToVector(vector<Node> &NodeSet, vector<int> &combination) {
//    vector<int> ans;
//
//    int n = combination.size();
//    for (int i = 0; i < n; i++) {
//        int id = combination[i];
//        vector<int> temp;
//        for (int j = 0; j < n; j++) {
//            if (i != j) {
//                temp.push_back(combination[j]);
//            }
//        }
//        if (checkSkyline(NodeSet, id, temp)) ans.push_back(1);
//        else ans.push_back(0);
//    }
//    return ans;
//}

long double sim(Node a, Node b) {
	long double ans = 0;
	ans =
			(a.stars * b.stars + a.review_count * b.review_count)
					/ (sqrt(a.stars * a.stars + a.review_count * a.review_count)
							* sqrt(
									b.stars * b.stars
											+ b.review_count * b.review_count));

	//cout<<ans<<endl;
	return ans;
}

long double avgTextualSim(Node a, int index, vector<vector<int> >&QuerySet) {
	int n = QuerySet.size();
	long double ans = 0;
	for (int i = 0; i < n; i++) {
		long double x = sim(a, NodeSet[QuerySet[i][index]]);

		//if(x>1+1e-8) cout<<x<<"  here   "<<a.stars <<"  "<<a.review_count<<"   "<<NodeSet[QuerySet[i][index]].stars<<"  "<<NodeSet[QuerySet[i][index]].review_count<<endl;

		ans += x;
	}

	return ans / n;
}

//double sim(vector<int> &a, vector<int> &b) {
//    double ans = 0;
//    for (int i = 0; i < a.size(); i++) {
//        if (a[i] <= b[i]) ans++;
//        else ans--;
//    }
//    return ans;
//}

long double GetTextualSim(vector<int> & Query, vector<int>& combination) {
	long double ans = 0;
	int n = Query.size();

	for (int i = 0; i < n; i++) {
		ans += sim(NodeSet[Query[i]], NodeSet[combination[i]]);
	}

	return ans / n;
}

vector<double> getSpatialVector(vector<int> & y) {
	vector<double> ans;
	ans.push_back(magnitude);
	int n = y.size();
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++) {
			ans.push_back(
					dist(NodeSet[y[i]].latitude, NodeSet[y[i]].longitude,
							NodeSet[y[j]].latitude, NodeSet[y[j]].longitude));
		}
	return ans;
}

long double GetSpatialSim(vector<int> & Query, vector<int>& combination) {
	long double ans = 0;
	vector<double> V1;
	vector<double> V2;

	V1 = getSpatialVector(Query);
	V2 = getSpatialVector(combination);

	for (int i = 0; i < V1.size(); i++)
		ans += V1[i] * V2[i];

	long double X = 0, Y = 0;
	for (int i = 0; i < V1.size(); i++) {
		X += (V1[i] * V1[i]);
		Y += (V2[i] * V2[i]);
	}
	ans /= (sqrt(X) * sqrt(Y));

	//if (ans > 1 + 1e-8) cout << "ERROR " << ans << endl;
	return ans;
}

long double GetSpatialSim(int index, vector<int>& combination) {
	long double ans = 0;
	//vector<double> V1;
	vector<double> V2;

	//V1 = SpatialVector[index];
	V2 = getSpatialVector(combination);

	for (int i = 0; i < SpatialVector[index].size(); i++)
		ans += SpatialVector[index][i] * (V2[i]);

	long double X = 0, Y = 0;
	for (int i = 0; i < SpatialVector[index].size(); i++) {
		X += (SpatialVector[index][i] * SpatialVector[index][i]);
		Y += (V2[i] * V2[i]);
	}
	ans /= sqrt(Y);
	ans /= sqrt(X);

	return ans;
}

long double sim(vector<int>& combination1, vector<int>& combination2) {
	return alpha * GetTextualSim(combination1, combination2)
			+ (1 - alpha) * GetSpatialSim(combination1, combination2);
}

long double sim(vector<vector<int> > &QuerySet, vector<int>& combination,
		double Currentweight) {
	long double ans = 0;

	for (int i = 0; i < QuerySet.size(); i++) {
		ans += alpha * GetSpatialSim(i, combination);
	}
	return (1 - alpha) * Currentweight / QuerySet[0].size()
			+ ans / QuerySet.size();

}

long double sim(vector<vector<int> > &QuerySet, vector<int>& combination) {
	long double ans = 0;

	for (int i = 0; i < QuerySet.size(); i++) {
		ans += (1 - alpha) * GetTextualSim(QuerySet[i], combination)
				+ alpha * GetSpatialSim(QuerySet[i], combination);
	}
	return ans * 1.0 / QuerySet.size();

}

double GetAvgDist(vector<Node> &NodeSet, vector<int> &combination) {
	double ans = 0;
	int n = combination.size();
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			ans += dist(NodeSet[combination[i]].latitude,
					NodeSet[combination[i]].longitude,
					NodeSet[combination[j]].latitude,
					NodeSet[combination[j]].longitude);

	return 2 * ans / (n * (n - 1));
}

double getUB(int flag, vector<int> & Y, vector<vector<int> > &querySet,
		vector<vector<PNode> >& List, int num, double CurrentWeight) {
	for (int i = num + 1; i < List.size(); i++)
		CurrentWeight += List[i][0].weight;
	if (flag != 0)
		return alpha + (1 - alpha) * CurrentWeight / List.size();

	double spatialUB = 0;
	double temp = 0.0;
	vector<double> V;
	int n = List.size();
	double A, C, D, S;
	extern double CostInSpatialUb;

	long start = clock();
	for (int i = 0; i < querySet.size(); i++) {
		A = C = D = S = 0.0;

		//        for (int j = 0; j < SpatialVector[i].size(); j++) {
		//            S += (SpatialVector[i][j] * SpatialVector[i][j]);
		//        }
		//        //assert(SpatialVector[i].size()== n*(n-1)/2 );
		//        S = sqrt(S);
		//        for (int j = 0; j < SpatialVector[i].size(); j++) {
		//            SpatialVector[i][j] /= S;
		//        }
		V.clear();
		for (int j = 0; j < n - 1; j++)
			for (int k = j + 1; k < n; k++) {
				if (j <= num - 1 && k <= num - 1)
					V.push_back(
							dist(NodeSet[Y[j]].latitude,
									NodeSet[Y[j]].longitude,
									NodeSet[Y[k]].latitude,
									NodeSet[Y[k]].longitude));
				else
					V.push_back(-1.0);
			}

		for (int j = 0; j < V.size(); j++) {
			if (V[j] > -0.1) {
				A += (SpatialVector[i][j] * V[j]);
				C += (V[j] * V[j]);
			} else {
				D += (SpatialVector[i][j] * SpatialVector[i][j]);
			}
		}

		//temp = sqrt(A * A / C + D);

		//temp = A/sqrt(C) + sqrt(D);
		//cout<<C<<endl;
		//temp = (A / sqrt(C) + sqrt(D)) / S;
		temp = max((A / sqrt(C) + sqrt(0.5 * D)), (A / sqrt(2 * C) + sqrt(D)));
		//if(C<1e-8) temp=1;
		// else temp=max( sqrt( A*(A/C)+ D/2+A*sqrt(2*D)/sqrt(C)),  sqrt(A*(A/C)/2+D+ A*sqrt(2*D)/ sqrt(C)));
		//cout<<"xxx   "<<temp<<endl;

		// if (temp + 1e-8 < 1.0) spatialUB += temp;
		// else spatialUB += 1.0;

		spatialUB += min(1.0, temp);
	}
	spatialUB /= querySet.size();

	CostInSpatialUb += clock() - start;

	//assert(CurrentWeight/ List.size() <1.0000001);

	return alpha * spatialUB + (1 - alpha) * CurrentWeight / List.size();
}

void dfs(vector<vector<PNode> >&List, int num, vector<vector<int> > &querySet,
		vector<int> & combination, priority_queue<QueueNode> & que,
		double CurrentWeight) {
	if (num == List.size()) {

		double similarity = sim(querySet, combination, CurrentWeight);

		COUNT++;
		//double similarity = sim(querySet, combination); //basic
		int sum = 0;
		for (int i = 0; i < combination.size(); i++)
			sum += combination[i];
		if (!BASELINE && sumHash[sum]) {
			int flag = 1;
			for (int i = 0; i < detailHash.size(); i++) {
				flag = 1;
				for (int j = 0; j < detailHash[i].size(); j++) {
					if (detailHash[i][j] != combination[j]) {
						flag = 0;
						break;
					}
				}
				if (flag)
					break;
			}
			if (flag)
				return;
		}
		if (que.size() < K) {

			que.push(
					QueueNode(combination, similarity,
							GetAvgDist(NodeSet, combination)));
		} else if (similarity > que.top().weight) {
			que.pop();
			que.push(
					QueueNode(combination, similarity,
							GetAvgDist(NodeSet, combination)));
		}
		return;
	}
	for (int i = 0; i < List[num].size(); i++) {
		combination[num] = List[num][i].id;

		if (!BASELINE && que.size() >= K && num > 0) {
			double UB = getUB(i, combination, querySet, List, num,
					CurrentWeight + List[num][i].weight);

			if (UB < 1e-9 + que.top().weight) {
				return;
			}
		}
		dfs(List, num + 1, querySet, combination, que,
				CurrentWeight + List[num][i].weight);
	}
}

/**
 * This method warms up the queue so that the effciency improves.
 * Currently this code is not good, I make a hard code on it to only handle querySet[0]
 * We insert K*|querySet[0]| good values into the queue
 * We put the K combinations composed of the first-K nodes corresponding to querySet[0][i] and other nodes querySet[0][j] (j !=i)
 */
void initQue(vector<vector<PNode> > &List, vector<vector<int> > &querySet,
		priority_queue<QueueNode>& que, int K) {
	memset(sumHash, 0, sizeof(sumHash));
	detailHash.clear();
	for (int j = 0; j < querySet[0].size(); j++) {
		for (int i = 1; i <= K; i++) {
			vector<int> combination;
			int sum = 0;
			for (int u = 0; u < querySet[0].size(); u++) {
				combination.push_back(querySet[0][u]);
				sum += querySet[0][u];
			}

			if (List[j].size() <= i)
				continue;
			sum -= combination[j];

			combination[j] = List[j][i].id;
			sum += combination[j];
			sumHash[sum] = 1;
//			cout << sum << " ";

			vector<int> temp(combination.begin(), combination.end());
			detailHash.push_back(temp);

			double similarity = sim(querySet, combination);
//			cout << similarity << " ";
			if (que.size() < K) {
				que.push(QueueNode(combination, similarity, 1));
			} else if (similarity > que.top().weight) {
				que.pop();
				que.push(QueueNode(combination, similarity, 1));
			}
		}
	}
//	cout << endl;
}

vector<QueueNode> getTopK(vector<Node> &NodeSet, vector<vector<int> > &querySet,
		double r) {
	priority_queue<QueueNode> que;
	vector<vector<PNode> > oriList;
	vector<vector<PNode> > oriListSpatial;
	vector<vector<PNode> > List;
	vector<vector<PNode> > ListSpatial;
	vector<vector<int> > changedQuerySet;
	long long possible = 1;
	for (int i = 0; i < querySet[0].size(); i++) {
		vector<PNode> pNodeList = FilterType(NodeSet, querySet[0][i], i,
				querySet, r);
		vector<PNode> pNodeListSpatial(pNodeList.begin(), pNodeList.end());
		if (!BASELINE) {
			sort(pNodeListSpatial.begin(), pNodeListSpatial.end(), comp2);
			sort(pNodeList.begin(), pNodeList.end(), comp);
		}

		oriList.push_back(pNodeList);
		oriListSpatial.push_back(pNodeListSpatial);
		possible *= pNodeList.size();
	}

//	for (int u = 0; u < querySet[0].size(); u++) {
//		cout << oriListSpatial[u][0].id << " ";
//	}
//	cout << endl;
//	for (int u = 0; u < querySet[0].size(); u++) {
//		cout << querySet[0][u] << " ";
//	}
//	cout << endl;

	for (int i = 0; i < 10; i++)
		numMapping[i] = i;
	int ListSizes[10];
	for (int i = 0; i < oriList.size(); i++) {
		ListSizes[i] = oriList[i].size();
//		cout << ListSizes[i] << " ";
	}
//	cout << endl;
	if (!BASELINE) {

		//bubble sort to sort the lists according to their sizes: from larger to smaller
		// the ranks are recorded in numMapping
		for (int i = 0; i < oriList.size(); i++) {
			for (int j = 0; j < oriList.size() - i - 1; j++) {
				if (ListSizes[j] > ListSizes[j + 1]) {
					int temp = numMapping[j];
					numMapping[j] = numMapping[j + 1];
					numMapping[j + 1] = temp;
					int tempSize = ListSizes[j];
					ListSizes[j] = ListSizes[j + 1];
					ListSizes[j + 1] = tempSize;
				}
			}
		}
	}

	int oriListSize = oriList.size();
	List.resize(oriListSize);
	ListSpatial.resize(oriListSize);
	for (int i = 0; i < oriListSize; i++) {
		for (int j = 0; j < oriList[numMapping[i]].size(); j++) {
			PNode a(oriList[numMapping[i]][j].id,
					oriList[numMapping[i]][j].weight,
					oriList[numMapping[i]][j].distance);
			List[i].push_back(a);
			PNode b(oriListSpatial[numMapping[i]][j].id,
					oriListSpatial[numMapping[i]][j].weight,
					oriListSpatial[numMapping[i]][j].distance);
			ListSpatial[i].push_back(b);
		}

	}

	// map original queryset to changedQuerySet, which changes the order of each query keyword according to their frequencies
	for (int i = 0; i < querySet.size(); i++) {
		vector<int> temp;
		temp.resize(oriListSize);
		for (int j = 0; j < oriListSize; j++) {
			temp[j] = querySet[i][numMapping[j]];
		}
		changedQuerySet.push_back(temp);
	}

	if (!BASELINE) {
		//initQue pushes several "good" values for bounding
		initQue(ListSpatial, changedQuerySet, que, K);
//		cout << endl;
	}

	SpatialVector.clear();
	for (int i = 0; i < changedQuerySet.size(); i++) {
		int mag_sum = 0;
		for (int j = 0; j < changedQuerySet[i].size(); j++)
			mag_sum += changedQuerySet[i][j];
		mag_sum /= changedQuerySet[0].size();
		magnitude = mag_sum;
		SpatialVector.push_back(getSpatialVector(changedQuerySet[i]));
	}
//	cout << possible << endl;
	COUNT = 0;

	vector<int> combination(List.size());
	dfs(List, 0, changedQuerySet, combination, que, 0);

	vector<QueueNode> ans;
	while (!que.empty()) {
		ans.push_back(que.top());
		que.pop();
	}
	reverse(ans.begin(), ans.end());

//	cout << "count " << COUNT << endl << endl;
//
	percentage += (possible - COUNT) * 1.0 / possible;
//	cout << "query set:" << endl;
//	for (int i = 0; i < changedQuerySet.size(); i++) {
//		for (int j = 0; j < changedQuerySet[i].size(); j++) {
//			int nodeid = changedQuerySet[i][j];
//			cout << nodeid << "(" << NodeSet[nodeid].latitude << ","
//					<< NodeSet[nodeid].longitude << ")\t";
//		}
//		cout << endl;
//	}
	return ans;
}

bool checkDist(double R, int a, int b) {
	return Spherical_distance(NodeSet[a].latitude, NodeSet[a].longitude,
			NodeSet[b].latitude, NodeSet[a].longitude) <= R;
}

bool checkType(int a, int b) // b is the corresponding query node
		{
	set<string>::iterator it;
	for (it = NodeSet[a].categories.begin(); it != NodeSet[a].categories.end();
			it++) {
		if (NodeSet[b].categories.find(*it) != NodeSet[b].categories.end())
			return true;
	}
	return false;
}

void QueryGenerator(string path, double R) {
	ofstream ofile;
	ofile.open(path.c_str());
	extern vector<Node> NodeSet;
	int Num = 1000;
	int exampleSize = 3;
	int exampleNum;
	//double R;

	ofile << Num << endl;
	cout << Num << endl;
	//Node size=3, example Number=2;  R= rand 2000 to 10000

	int n = NodeSet.size();

	srand((unsigned) time(NULL));
	bool used[n + 1];
	while (Num > 0) {
		//cout<<Num<<endl;
		//R = 1000; // + (int) rand() % 1000;
		exampleNum = 1 + (int) rand() % 1;
		memset(used, 0, sizeof(used));
		//generate first example
		int seed = (int) rand() % n;
		vector<int> query;
		used[seed] = 1;
		query.push_back(seed);
		int count = 1;
		set<string> typeSet;
		if (NodeSet[seed].categories.empty())
			continue;
		typeSet.insert(*NodeSet[seed].categories.begin());
		for (int j = 0; j < n; j++) {
			if (!used[j] && checkDist(R, j, seed) == true
					&& !NodeSet[j].categories.empty()
					&& typeSet.find(*NodeSet[j].categories.begin())
							== typeSet.end()) {
				used[j] = 1;
				query.push_back(j);
				count++;
				typeSet.insert(*NodeSet[j].categories.begin());
				if (count == exampleSize)
					break;
			}
		}
		if (query.size() != exampleSize)
			continue;

		vector<vector<int> > RestExamples;
		for (int w = 1; w < exampleNum; w++) {
			count = 0;
			vector<int> query2;
			for (int j = 0; j < n; j++) {
				if (!used[j] && checkDist(R, j, seed) == true
						&& checkType(j, query[count])) {
					query2.push_back(j);
					count++;
					used[j] = 1;
					if (count == exampleSize)
						break;
				}
			}
			if (count != exampleSize)
				break;
			RestExamples.push_back(query2);
		}
		if (RestExamples.size() != exampleNum - 1)
			continue;

		ofile << R << " " << exampleNum << " " << exampleSize << endl;
		//cout << R << " " << exampleNum << " " << exampleSize << endl;

		for (int j = 0; j < exampleSize; j++) {
			if (j == 0) {
				ofile << query[j];
				//      cout<<query[j];
			} else {
				ofile << " " << query[j];
				//	cout<<" "<<query[j];
			}
		}
		ofile << endl;
		//cout<<endl;

		for (int w = 0; w < RestExamples.size(); w++) {

			for (int j = 0; j < exampleSize; j++) {
				if (j == 0) {
					ofile << RestExamples[w][j];
					//          cout<<RestExamples[w][j];
				} else {
					ofile << " " << RestExamples[w][j];
					//      	cout<<" "<<RestExamples[w][j];
				}
			}
			ofile << endl;
			//  cout<<endl;
		}
		Num--;
	}
	cout << "generate query ends ..." << endl;
	ofile.close();
	ofile.clear();
}

vector<vector<vector<int> > > ReadQuery(string path) {
	ifstream ifile;
	ifile.open(path.c_str());
	if (ifile.fail()) {
		cout << "file not found in ReadQuery" << endl;
	}
	int N;
	ifile >> N;
	vector<vector<vector<int> > > QuerySetList;
	RadioSet.clear();
	int temp;
	for (int i = 0; i < N; i++) {
		double R;
		int exampleNum;
		int exampleSize;
		ifile >> R >> exampleNum >> exampleSize;
		RadioSet.push_back(R);
		vector<vector<int> > QuerySet;
		for (int j = 0; j < exampleNum; j++) {
			vector<int> example;

			for (int k = 0; k < exampleSize; k++) {
				ifile >> temp;
				example.push_back(temp);
			}
			if (ONLY_ONE_EX == 1 && j == 0 || ONLY_ONE_EX != 1)
				QuerySet.push_back(example);
		}
		QuerySetList.push_back(QuerySet);
	}
	ifile.close();
	cout << QuerySetList.size() << endl;
	return QuerySetList;
}

void BuildIndex() {
	//   extern vector<Node> NodeSet;
	//   extern map<string, set<int> > InvertedList;
	int num = 0;
	int n = NodeSet.size();
	for (int i = 0; i < n; i++) {
		for (string e : NodeSet[i].categories) {
			if (InvertedList.find(e) != InvertedList.end()) {
				InvertedList[e].insert(i);
			} else {
				set<int> s;
				s.insert(i);
				InvertedList.insert(pair<string, set<int> >(e, s));
			}
		}
	}
	cout << "num:" << num << endl;
}

void case_study() {
	//	"Hotels&Travel"
	//  CaseStudyFor3Nodes(NodeSet, "Arts&Crafts", "Libraries","Colleges&Universities", "Apartments");
	//ChildCare&DayCare
	cout << endl << endl;
	cout << "------------------------------------" << endl;
	cout << "Starting Case Study for 3 nodes..." << endl;
	cout << "Test two cases for strict constraints..." << endl;
//		CaseStudyFor3Nodes(NodeSet, "ChildCare&DayCare", "Libraries", "Apartments",
//				10);
	vector<vector<int> > all_examples=CaseStudyFor3Nodes(NodeSet, "Restaurants", "Libraries", "Apartments", 10);
	vector<vector<int> > qSet;
	vector<int> qSetExample;
	//top-1
	cout << "The result based on similarity measure: (Top-1)" << endl;
	//we input the top-10 result of the Case 1 in case studies
//		qSetExample.push_back(14683);
//		qSetExample.push_back(13614);
//		qSetExample.push_back(19883);

	// case study 1 in paper
//	qSetExample.push_back(63956);
//	qSetExample.push_back(69550);
//	qSetExample.push_back(31711);

	int cnt=0;
	for(vector<int> qSetExample:all_examples){
	qSet.push_back(qSetExample);
	vector<QueueNode> ans = getTopK(NodeSet, qSet, RadioSet[0]);
	cout<<"The SEQ result for "<<cnt<<" th example:"<<endl;
	cnt++;
	for (int i = 1; i < ans.size(); i++) {
		cout << "Sim=" << ans[i].weight << "\t";
		for (int j = 0; j < ans[i].id.size(); j++) {
			cout<<"stars: "<<NodeSet[ans[i].id[j]].stars<< "review_cnt: "<<NodeSet[ans[i].id[j]].review_count;
			cout << ans[i].id[j] << " lat: " << NodeSet[ans[i].id[j]].latitude << ", lng: "
					<< NodeSet[ans[i].id[j]].longitude << "\t";
		}
		cout << endl;
		cout << "Pair-wise distances: ";
		for (int u = 0; u < ans[i].id.size(); u++) {
			for (int v = u + 1; v < ans[i].id.size(); v++) {
				int m = ans[i].id[u];
				int n = ans[i].id[v];
				cout
						<< Spherical_distance(NodeSet[m].latitude,
								NodeSet[m].longitude, NodeSet[n].latitude,
								NodeSet[n].longitude) << " ";
			}

		}
		cout<<endl;
		for(int j=0;j<3;j++){
							cout<<"myLatLng.push({lat: "<<NodeSet[ans[i].id[j]].latitude<<","<<
									"lng:"<<NodeSet[ans[i].id[j]].longitude<<"});"<<endl;
		}
		cout<<"myLatLng.push({lat: "<<NodeSet[ans[i].id[0]].latitude<<","<<
											"lng:"<<NodeSet[ans[i].id[0]].longitude<<"});"<<endl;
							cout<<endl;
		cout << endl;
	}
	}
	cout << endl;
	exit(0);
}
int main(int argc, char** argv) {

	extern vector<Node> NodeSet;
	extern int K;

	Read(NodeSet, "yelp_academic_dataset_business.txt");

	//    for(int i=0;i<10;i++){
	//    Node node = NodeSet[i];
	//    cout << node.business_id << "; " << node.name << "; " << node.latitude << "; " << node.longitude << "; " << node.stars << "; " << node.review_count;
	//    cout << "; " << node.categories.size();
	//    for (int i = 0; i < node.categories.size(); i++)
	//        cout << "; " << node.categories[i];
	//    cout << endl;
	//    }
	string QueryFilePath = "queries_";

	string stringR[] = { "1000", "2000", "3000", "4000", "5000" };
//	    for(int i=1;i<2;i++)
//	      QueryGenerator(QueryFilePath+stringR[i]+".txt", 1000.0*(i+1));
//	    exit(0);

	// a map from category to a list of node ids that contain this category
	BuildIndex();
	int Q = 2;
	string path = QueryFilePath + stringR[Q] + ".txt";
	vector<vector<vector<int> > > QuerySet;
	QuerySet = ReadQuery(path);

	cout << "Finished reading querySet" << endl;
//	case_study();
	int kSet[5] = { 1, 5, 10, 20, 50 };
	for (int x = 0; x < 5; x++) {

		K = kSet[x];

		//timeval start1, end;

		long start;

		for (alpha = 0.1; alpha < 0.99; alpha += 0.1) {

			start = clock();
			//gettimeofday(&start1, NULL);
			CostInSpatialUb = 0;

			//     int CASE = QuerySet.size();
			int CASE = 100;
			int cas;
			for (cas = 0; cas < CASE; cas++) {
				//cout << cas << endl;
				//   	if(QuerySet[cas].size()!=1) continue;
				//   	if(QuerySet[cas][0].size()!=4) continue;

				vector<QueueNode> ans = getTopK(NodeSet, QuerySet[cas],
						RadioSet[cas]);

//                        for (int i = 0; i < ans.size(); i++) {
//                            cout << "Sim=" << ans[i].weight << "\t";
//                            for (int j = 0; j < ans[i].id.size(); j++) {
//                                cout << ans[i].id[j] << "(" << NodeSet[ans[i].id[j]].latitude << "," << NodeSet[ans[i].id[j]].longitude << ")\t";
//                            }
//                            cout << endl;
//                        }
//                        cout << endl;
				//      exit(0);
			}

			//        gettimeofday(&end, NULL);
			//        long long mtime, seconds, useconds;
			//        seconds = end.tv_sec - start1.tv_sec;
			//        useconds = end.tv_usec - start1.tv_usec;
			//        mtime = seconds * 1000000 + useconds;
			//        printf("ltime: %lld μs\n", mtime/cas);

			long end = clock();
			cout << "alpha: " << alpha << " range: " << stringR[Q] << " ";
			cout << "k=" << kSet[x] << "  " << (end - start) / (1000 * cas)
					<< "ms  " << (end - CostInSpatialUb - start) / (1000 * cas)
					<< "ms" << endl;

			cout << 100 * percentage / cas << "%" << endl;
		}
	}
	return 0;
}

